
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/send-push.mjs
import webpush from "web-push";
var SUPABASE_URL = process.env.SUPABASE_URL || "https://bsmvfutebmbkjvlrhiyq.supabase.co";
var SUPABASE_SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY;
var VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY;
var VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;
var VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:4mattcarlson@gmail.com";
function mountainHour() {
  const utcHour = (/* @__PURE__ */ new Date()).getUTCHours();
  const offset = isDST() ? -6 : -7;
  return (utcHour + offset + 24) % 24;
}
function mountainDow() {
  const now = /* @__PURE__ */ new Date();
  const mt = new Date(now.getTime() + (isDST() ? -6 : -7) * 36e5);
  return mt.getUTCDay();
}
function mountainDateStr() {
  const now = /* @__PURE__ */ new Date();
  const mt = new Date(now.getTime() + (isDST() ? -6 : -7) * 36e5);
  return mt.toISOString().split("T")[0];
}
function isDST() {
  const now = /* @__PURE__ */ new Date();
  const y = now.getUTCFullYear();
  const dstStart = nthSunday(y, 2, 2);
  const dstEnd = nthSunday(y, 10, 1);
  return now >= dstStart && now < dstEnd;
}
function nthSunday(year, month, nth) {
  const d = new Date(Date.UTC(year, month - 1, 1));
  const firstSun = (7 - d.getUTCDay()) % 7;
  return new Date(Date.UTC(year, month - 1, 1 + firstSun + (nth - 1) * 7, 8));
}
async function fetchSubscriptions() {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/push_subscriptions?select=endpoint,p256dh,auth,prefs`,
    {
      headers: {
        "apikey": SUPABASE_SERVICE,
        "Authorization": `Bearer ${SUPABASE_SERVICE}`
      }
    }
  );
  if (!res.ok) throw new Error(`Supabase error: ${res.status}`);
  return res.json();
}
async function fetchTonightCount(dateStr) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/events?select=id&start_date=eq.${dateStr}`,
    {
      headers: {
        "apikey": SUPABASE_SERVICE,
        "Authorization": `Bearer ${SUPABASE_SERVICE}`,
        "Prefer": "count=exact",
        "Range": "0-0"
      }
    }
  );
  const ch = res.headers.get("Content-Range") || "";
  const m = ch.match(/\/(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}
async function fetchWeekendCount(satStr, sunStr) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/events?select=id&start_date=in.(${satStr},${sunStr})`,
    {
      headers: {
        "apikey": SUPABASE_SERVICE,
        "Authorization": `Bearer ${SUPABASE_SERVICE}`,
        "Prefer": "count=exact",
        "Range": "0-0"
      }
    }
  );
  const ch = res.headers.get("Content-Range") || "";
  const m = ch.match(/\/(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}
async function sendToSubscriber(sub, payload) {
  try {
    await webpush.sendNotification(
      { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
      JSON.stringify(payload)
    );
    return true;
  } catch (err) {
    if (err.statusCode === 410 || err.statusCode === 404) {
      await fetch(
        `${SUPABASE_URL}/rest/v1/push_subscriptions?endpoint=eq.${encodeURIComponent(sub.endpoint)}`,
        {
          method: "DELETE",
          headers: {
            "apikey": SUPABASE_SERVICE,
            "Authorization": `Bearer ${SUPABASE_SERVICE}`
          }
        }
      );
    }
    return false;
  }
}
async function handler() {
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
    console.error("[send-push] Missing VAPID keys");
    return new Response("Missing VAPID keys", { status: 500 });
  }
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
  const hour = mountainHour();
  const dow = mountainDow();
  const today = mountainDateStr();
  const satOffset = dow === 6 ? 0 : (6 - dow + 7) % 7;
  const sunOffset = dow === 0 ? 0 : (7 - dow) % 7;
  const sat = /* @__PURE__ */ new Date();
  sat.setDate(sat.getDate() + satOffset);
  const sun = /* @__PURE__ */ new Date();
  sun.setDate(sun.getDate() + sunOffset);
  const satStr = sat.toISOString().split("T")[0];
  const sunStr = sun.toISOString().split("T")[0];
  console.log(`[send-push] MT hour=${hour} dow=${dow} date=${today}`);
  let notifType = null;
  if (hour === 17) notifType = "tonight";
  if ((dow === 4 || dow === 5) && hour === 9) notifType = "weekend";
  if (dow === 1 && hour === 8) notifType = "categories";
  if ((dow === 5 || dow === 6) && hour === 9) notifType = "free";
  if (!notifType) {
    console.log("[send-push] No notification scheduled this hour");
    return new Response("No notification this hour", { status: 200 });
  }
  const subs = await fetchSubscriptions();
  console.log(`[send-push] ${subs.length} subscribers, type=${notifType}`);
  let sent = 0, skipped = 0, failed = 0;
  for (const sub of subs) {
    const prefs = sub.prefs || {};
    if (!prefs.enabled) {
      skipped++;
      continue;
    }
    let payload = null;
    if (notifType === "tonight" && prefs.tonight) {
      const count = await fetchTonightCount(today);
      if (count > 0) {
        payload = {
          title: `\u{1F306} ${count} events tonight in ABQ`,
          body: "Tap to see what's happening in Albuquerque tonight.",
          tag: "abq-tonight",
          data: { url: "/#events", filter: "Tonight" }
        };
      }
    }
    if (notifType === "weekend" && prefs.weekend) {
      const count = await fetchWeekendCount(satStr, sunStr);
      if (count > 0) {
        payload = {
          title: `\u{1F5D3}\uFE0F ${count} events this weekend in ABQ`,
          body: "Your Albuquerque weekend preview is ready \u2014 tap to explore.",
          tag: "abq-weekend",
          data: { url: "/#events", filter: "This Weekend" }
        };
      }
    }
    if (notifType === "free" && prefs.freeEvents) {
      payload = {
        title: "\u{1F193} Free events this weekend in ABQ",
        body: "Free things to do in Albuquerque this weekend \u2014 no ticket needed.",
        tag: "abq-free",
        data: { url: "/#events", filter: "Free" }
      };
    }
    if (notifType === "categories" && prefs.myCategories) {
      payload = {
        title: "\u{1F3B8} New events in your categories this week",
        body: "Fresh events in Albuquerque that match your interests.",
        tag: "abq-categories",
        data: { url: "/#events", filter: "\u2764\uFE0F For You" }
      };
    }
    if (!payload) {
      skipped++;
      continue;
    }
    const ok = await sendToSubscriber(sub, payload);
    if (ok) sent++;
    else failed++;
  }
  console.log(`[send-push] Done: sent=${sent} skipped=${skipped} failed=${failed}`);
  return new Response(JSON.stringify({ sent, skipped, failed }), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
}
var config = {
  schedule: "0 * * * *"
  // every hour — handler decides which to send
};
export {
  config,
  handler as default
};
