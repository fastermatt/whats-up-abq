
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/save-reminder.mjs
var SUPABASE_URL = process.env.SUPABASE_URL || "https://bsmvfutebmbkjvlrhiyq.supabase.co";
var SUPABASE_SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY;
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }
  if (req.method === "DELETE") {
    let body2;
    try {
      body2 = await req.json();
    } catch {
      return new Response("Bad JSON", { status: 400, headers: corsHeaders() });
    }
    const { endpoint: endpoint2, eventId: eventId2 } = body2;
    if (!endpoint2 || !eventId2) return new Response("Missing fields", { status: 400, headers: corsHeaders() });
    await fetch(
      `${SUPABASE_URL}/rest/v1/event_reminders?endpoint=eq.${encodeURIComponent(endpoint2)}&event_id=eq.${encodeURIComponent(eventId2)}`,
      {
        method: "DELETE",
        headers: {
          "apikey": SUPABASE_SERVICE,
          "Authorization": `Bearer ${SUPABASE_SERVICE}`
        }
      }
    );
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { ...corsHeaders(), "Content-Type": "application/json" } });
  }
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders() });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response("Bad JSON", { status: 400, headers: corsHeaders() });
  }
  const { endpoint, eventId, eventName, eventDate, reminderDays } = body;
  if (!endpoint || !eventId || !eventDate || !reminderDays) {
    return new Response(JSON.stringify({ error: "Missing required fields" }), {
      status: 400,
      headers: { ...corsHeaders(), "Content-Type": "application/json" }
    });
  }
  const evDate = new Date(eventDate);
  evDate.setDate(evDate.getDate() - reminderDays);
  const remindOnDate = evDate.toISOString().split("T")[0];
  const res = await fetch(`${SUPABASE_URL}/rest/v1/event_reminders`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "apikey": SUPABASE_SERVICE,
      "Authorization": `Bearer ${SUPABASE_SERVICE}`,
      "Prefer": "resolution=merge-duplicates"
    },
    body: JSON.stringify({
      endpoint,
      event_id: eventId,
      event_name: eventName,
      event_date: eventDate,
      reminder_days: reminderDays,
      remind_on_date: remindOnDate,
      sent: false,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    })
  });
  if (!res.ok) {
    const text = await res.text();
    console.error("[save-reminder] Supabase error:", text);
    return new Response(JSON.stringify({ error: "Failed to save" }), {
      status: 500,
      headers: { ...corsHeaders(), "Content-Type": "application/json" }
    });
  }
  return new Response(JSON.stringify({ ok: true, remindOnDate }), {
    status: 200,
    headers: { ...corsHeaders(), "Content-Type": "application/json" }
  });
}
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}
var config = { path: "/api/save-reminder" };
export {
  config,
  handler as default
};
