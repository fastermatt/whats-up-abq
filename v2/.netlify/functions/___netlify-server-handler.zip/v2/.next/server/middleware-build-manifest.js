globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/qYbjs0gU2pndpoJazmObG/_buildManifest.js",
    "static/qYbjs0gU2pndpoJazmObG/_ssgManifest.js",
    "static/qYbjs0gU2pndpoJazmObG/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0l051pgv25116.js",
    "static/chunks/15dn2pq21uomb.js",
    "static/chunks/029cp2jfvvm3f.js",
    "static/chunks/turbopack-0j~yno51va4rv.js"
  ]
};
